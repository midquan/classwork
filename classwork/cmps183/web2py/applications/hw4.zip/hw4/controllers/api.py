import tempfile

# Cloud-safe of uuid, so that many cloned servers do not all use the same uuids.
from gluon.utils import web2py_uuid

# Here go your api methods.

def get_user_images():
    start_idx = int(request.vars.start_idx) if request.vars.start_idx is not None else 0
    end_idx = int(request.vars.end_idx) if request.vars.end_idx is not None else 0
    images = []
    image_url = db().select(db.user_images.ALL)
    for i, r in enumerate(image_url):
        if i < end_idx - start_idx:
            img = dict(
                created_on=r.created_on,
                created_by=r.created_by,
                image_url=r.image_url,
            )
            images.append(img)
    return response.json(dict(
        user_images=images,
    ))

@auth.requires_login()    
@auth.requires_signature()
def add_image():
    image_id = db.user_images.insert( image_url=request.vars.image_url,)
    im = db.user_images(image_id)
    user_images = dict(
        id=im.id,
        image_url=request.vars.image_url,
    )
    return response.json(dict(user_images=user_images,))

def get_users():
    start_idx = int(request.vars.start_idx) if request.vars.start_idx is not None else 0
    end_idx = int(request.vars.end_idx) if request.vars.end_idx is not None else 0
    user_list = []
    rows = db().select(db.auth_user.ALL, limitby=(start_idx, end_idx + 1)) 
    for i, r in enumerate(rows):
        if i < end_idx - start_idx:
            users = dict(
                first_name = r.first_name,
                last_name = r.last_name,
                email = r.email,
                id = r.id
            )
            user_list.append(users)
    return response.json(dict(
        user_list=user_list
    ))