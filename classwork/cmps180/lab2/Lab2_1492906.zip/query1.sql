-- Lab2
-- Michael Quan
-- query1.sql

SELECT DISTINCT jobLevel FROM IRSagents
ORDER BY jobLevel DESC;