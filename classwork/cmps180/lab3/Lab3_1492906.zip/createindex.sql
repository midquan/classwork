-- Lab3
-- Michael Quan
-- createindex.sql

CREATE INDEX LookUpReturns ON TaxReturns(kind, dateFiled);